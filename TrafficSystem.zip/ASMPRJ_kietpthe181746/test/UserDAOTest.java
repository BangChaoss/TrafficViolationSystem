import dao.UserDAO;
import model.User;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

public class UserDAOTest {
    @Test

    public    void testAddUser() throws Exception {
        UserDAO userDAO = new UserDAO();
        User user = new User();
        user.setFullName("Test User");
        user.setEmail("testuser@example.com");
        user.setPassword("password123");
        user.setRole("Citizen");
        user.setPhone("123456789");
        user.setAddress("123 Test Street");

        boolean result = userDAO.addUser(user);
        assertTrue(result, "User should be added successfully");
    }
@Test
  public  void testGetUserByEmail() throws Exception {
        UserDAO userDAO = new UserDAO();
        
        // Assuming a user with this email exists in the database
        String testEmail = "existinguser@example.com";
        
        User user = userDAO.getUserByEmail(testEmail);
        
        assertNotNull(user, "User should be retrieved successfully");
        assertEquals(testEmail, user.getEmail(), "Email should match the retrieved user");
        assertEquals("Existing User", user.getFullName(), "Full name should match the retrieved user");
    }
}


