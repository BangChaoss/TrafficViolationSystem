/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
    import dao.ReportDAO;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/**
 *
 * @author le284
 */

public class ReportDAOTest {
    @Test
 public   void testSaveReport() throws Exception {
        ReportDAO reportDAO = new ReportDAO();
        boolean result = reportDAO.saveReport(
            1, // reporterID
            "Speeding", // violationType
            "Exceeded speed limit by 20km/h", // description
            "ABC123", // plateNumber
            "Main Street", // location
            null, // imageURL
            null  // videoURL
        );

        assertTrue(result, "Report should be saved successfully");
    }

}
