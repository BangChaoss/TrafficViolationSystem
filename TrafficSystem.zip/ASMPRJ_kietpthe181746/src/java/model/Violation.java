package model;

import java.util.Date;

public class Violation {

    private int violationID;
    private int reportID;
    private String plateNumber;
    private int violatorID;
    private double fineAmount;
    private Date fineDate;
    private String paidStatus; 

    public Violation(int violationID, int reportID, String plateNumber, int violatorID, double fineAmount, String paidStatus) {
        this.violationID = violationID;
        this.reportID = reportID;
        this.plateNumber = plateNumber;
        this.violatorID = violatorID;
        this.fineAmount = fineAmount;
        this.fineDate = fineDate;
        this.paidStatus = paidStatus; 
    }

    public int getViolationID() {
        return violationID;
    }

    public void setViolationID(int violationID) {
        this.violationID = violationID;
    }

    public int getReportID() {
        return reportID;
    }

    public void setReportID(int reportID) {
        this.reportID = reportID;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public void setPlateNumber(String plateNumber) {
        this.plateNumber = plateNumber;
    }

    public int getViolatorID() {
        return violatorID;
    }

    public void setViolatorID(int violatorID) {
        this.violatorID = violatorID;
    }

    public double getFineAmount() {
        return fineAmount;
    }

    public void setFineAmount(double fineAmount) {
        this.fineAmount = fineAmount;
    }

    public Date getFineDate() {
        return fineDate;
    }

    public void setFineDate(Date fineDate) {
        this.fineDate = fineDate;
    }

    public String getPaidStatus() {
        return paidStatus;
    }

    public void setPaidStatus(String paidStatus) {
        this.paidStatus = paidStatus;
    }

}
