/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author phucn
 */
public class Vehicle {

    private int vehicleID;
    private String plateNumber;
    private int ownerID;
    private String brand;
    private String model;
    private int manufactureYear;

    public Vehicle() {
    }

    public Vehicle(int vehicleID, String plateNumber, int ownerID, String brand, String model, int manufactureYear) {
        this.vehicleID = vehicleID;
        this.plateNumber = plateNumber;
        this.ownerID = ownerID;
        this.brand = brand;
        this.model = model;
        this.manufactureYear = manufactureYear;
    }

    // Getters & Setters
    public int getVehicleID() {
        return vehicleID;
    }

    public void setVehicleID(int vehicleID) {
        this.vehicleID = vehicleID;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public void setPlateNumber(String plateNumber) {
        this.plateNumber = plateNumber;
    }

    public int getOwnerID() {
        return ownerID;
    }

    public void setOwnerID(int ownerID) {
        this.ownerID = ownerID;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getManufactureYear() {
        return manufactureYear;
    }

    public void setManufactureYear(int manufactureYear) {
        this.manufactureYear = manufactureYear;
    }
}
