package model;

import java.sql.Timestamp;

public class Report {
    private int reportID;
    private int reporterID;
    private String violationType;
    private String description;
    private String plateNumber;
    private String imageURL;
    private String videoURL;
    private String location;
    private Timestamp reportDate;
    private String status;
    private Integer processedBy;

    public Report(int reportID, int reporterID, String violationType, String description, String plateNumber,
                  String imageURL, String videoURL, String location, Timestamp reportDate, String status, Integer processedBy) {
        this.reportID = reportID;
        this.reporterID = reporterID;
        this.violationType = violationType;
        this.description = description;
        this.plateNumber = plateNumber;
        this.imageURL = imageURL;
        this.videoURL = videoURL;
        this.location = location;
        this.reportDate = reportDate;
        this.status = status;
        this.processedBy = processedBy;
    }

    public int getReportID() {
        return reportID;
    }

    public void setReportID(int reportID) {
        this.reportID = reportID;
    }

    public int getReporterID() {
        return reporterID;
    }

    public void setReporterID(int reporterID) {
        this.reporterID = reporterID;
    }

    public String getViolationType() {
        return violationType;
    }

    public void setViolationType(String violationType) {
        this.violationType = violationType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public void setPlateNumber(String plateNumber) {
        this.plateNumber = plateNumber;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getVideoURL() {
        return videoURL;
    }

    public void setVideoURL(String videoURL) {
        this.videoURL = videoURL;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Timestamp getReportDate() {
        return reportDate;
    }

    public void setReportDate(Timestamp reportDate) {
        this.reportDate = reportDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getProcessedBy() {
        return processedBy;
    }

    public void setProcessedBy(Integer processedBy) {
        this.processedBy = processedBy;
    }

  
}
