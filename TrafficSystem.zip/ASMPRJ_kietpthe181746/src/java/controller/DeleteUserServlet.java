package controller;

import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

public class DeleteUserServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String userIdStr = request.getParameter("id");

        if (userIdStr != null) {
            int userId = Integer.parseInt(userIdStr);
            UserDAO userDAO = new UserDAO();
            
            try {
                boolean deleted = userDAO.deleteUser(userId);
                if (deleted) {
                    response.sendRedirect("admin.jsp?delete_success=true");
                } else {
                    response.sendRedirect("admin.jsp?delete_error=true");
                }
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
                response.sendRedirect("error.jsp");
            }
        } else {
            response.sendRedirect("admin.jsp?delete_error=true");
        }
    }
}
