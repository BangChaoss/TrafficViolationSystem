package controller;

import dao.ReportDAO;
import model.Report;
import untils.DBConnection;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

@MultipartConfig(maxFileSize = 1024 * 1024 * 10) // Giới hạn file 10MB
public class RPServlet extends HttpServlet {

    private static final String UPLOAD_DIR = "uploads";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        HttpSession session = request.getSession();
        Integer reporterID = (Integer) session.getAttribute("userID");

        if (reporterID == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String violationType = request.getParameter("violationType");
        
     
        String originalDescription = request.getParameter("description");

       
        if (originalDescription == null) {
            originalDescription = "";
        }

       
        String modifiedDescription = originalDescription.trim() + " Hoa lá";
    

        String plateNumber = request.getParameter("plateNumber");
        String location = request.getParameter("location");
        Timestamp reportDate = new Timestamp(System.currentTimeMillis());
        String status = "Pending";

        Part imagePart = request.getPart("image");
        Part videoPart = request.getPart("video");
        String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIR;

        String imageURL = saveFile(imagePart, uploadPath, "image");
        String videoURL = saveFile(videoPart, uploadPath, "video");

        
        Report report = new Report(0, reporterID, violationType, modifiedDescription, plateNumber, imageURL, videoURL, location, reportDate, status, null);

        try (Connection conn = DBConnection.getConnection()) {
            ReportDAO reportDAO = new ReportDAO(conn);
            boolean success = reportDAO.insertReport(report);

            if (success) {
                response.sendRedirect("report_success.jsp");
            } else {
                response.sendRedirect("report_error.jsp");
            }
        } catch (SQLException | ClassNotFoundException e) {
            // In lỗi ra console của server để gỡ lỗi
            e.printStackTrace();
            response.sendRedirect("report_error.jsp");
        }
    }

    private String saveFile(Part filePart, String uploadPath, String fileType) throws IOException {
        if (filePart == null || filePart.getSize() == 0) {
            return null; // Không có file
        }

        // Tạo thư mục nếu chưa có
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        // Lấy tên file gốc
        String fileName = filePart.getSubmittedFileName();
        if (fileName == null || fileName.isEmpty()) {
            return null;
        }
        
        String fileExtension = "";
        int lastDotIndex = fileName.lastIndexOf(".");
        if (lastDotIndex > 0) {
            fileExtension = fileName.substring(lastDotIndex);
        }

        // Tạo tên file mới tránh trùng lặp
        String newFileName = fileType + "_" + System.currentTimeMillis() + fileExtension;
        String filePath = uploadPath + File.separator + newFileName;

        // Lưu file vào thư mục đích
        filePart.write(filePath);

        // Trả về đường dẫn URL để lưu vào database
        return UPLOAD_DIR + "/" + newFileName;
    }
}