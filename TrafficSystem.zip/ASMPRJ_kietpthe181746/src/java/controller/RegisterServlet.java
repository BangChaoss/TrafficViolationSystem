 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.UserDAO;
import model.User;
import untils.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

/**
 *
 * @author phucn
 */
public class RegisterServlet extends HttpServlet {

    private int userID;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RegisterServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet RegisterServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String phone = request.getParameter("phone");
        String role = request.getParameter("role"); // Giờ có thể nhập tự do
        String address = request.getParameter("address");

        if (!password.equals(confirmPassword)) {
            request.setAttribute("message", "Mật khẩu xác nhận không khớp!");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        User user = new User(userID, fullName, email, password, role, phone, address);
        UserDAO userDAO = new UserDAO();

        try {
            if (userDAO.isEmailExists(email)) {
                request.setAttribute("message", "Email đã tồn tại! Vui lòng sử dụng email khác.");
                request.getRequestDispatcher("register.jsp").forward(request, response);
                return;
            }

            boolean success = userDAO.registerUser(user);
            if (success) {
                request.setAttribute("message", "Đăng ký thành công! Vui lòng đăng nhập.");
                request.getRequestDispatcher("register.jsp").forward(request, response);
            } else {
                request.setAttribute("message", "Lỗi đăng ký! Vui lòng thử lại.");
                request.getRequestDispatcher("register.jsp").forward(request, response);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("message", "Lỗi hệ thống! Vui lòng thử lại sau.");
            request.getRequestDispatcher("register.jsp").forward(request, response);
        }
    }
//        if (!password.equals(confirmPassword)) {
//            request.setAttribute("message", "⚠️ Mật khẩu không khớp!");
//            request.getRequestDispatcher("register.jsp").forward(request, response);
//            return;
//        }
//
//        // Tạo đối tượng User
//        User newUser = new User(fullName, email, password, phone, address, role);
//
//        // Thử đăng ký
//        try {
//          
//            boolean success = userDAO.registerUser(newUser);
//
//            if (success) {
//                request.setAttribute("message", "✅ Đăng ký thành công!");
//                response.sendRedirect("index.jsp");
//            } else {
//                request.setAttribute("message", "⚠️ Đăng ký thất bại! Email đã tồn tại.");
//                request.getRequestDispatcher("register.jsp").forward(request, response);
//            }
//        } catch (SQLException | ClassNotFoundException e) {
//            e.printStackTrace(); // In lỗi ra log server
//            request.setAttribute("message", "⚠️ Lỗi hệ thống: " + e.getMessage());
//            request.getRequestDispatcher("register.jsp").forward(request, response);
//        }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
