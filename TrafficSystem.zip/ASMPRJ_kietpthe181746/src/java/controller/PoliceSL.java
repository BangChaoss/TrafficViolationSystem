package controller;

import dao.ReportDAO;
import dao.ViolationDAO;
import dao.NotiDAO;
import dao.VehicleDAO;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class PoliceSL extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private ReportDAO reportDAO;

    public PoliceSL() {
        super();
        reportDAO = new ReportDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        try {
            int reportId = Integer.parseInt(request.getParameter("reportId"));
            String plateNumber = request.getParameter("plateNumber");
            String status = request.getParameter("status");

            HttpSession session = request.getSession();
            Integer officerId = (Integer) session.getAttribute("userID");

            if (officerId == null) {
                response.sendRedirect("login.jsp?error=session_expired");
                return;
            }

            boolean statusUpdated = reportDAO.updateReportStatus(reportId, status, officerId);

            if ("Approved".equals(status)) {
                double fineAmount = Double.parseDouble(request.getParameter("fineAmount"));

                // Lấy OwnerID từ Vehicles
                VehicleDAO vehicleDAO = new VehicleDAO();
                int ownerId = vehicleDAO.getOwnerIdByPlate(plateNumber);

                ViolationDAO violationDAO = new ViolationDAO();
                boolean violationRecorded = violationDAO.addViolation(reportId, plateNumber, ownerId, fineAmount);

                NotiDAO notiDAO = new NotiDAO();
                boolean notificationSent = notiDAO.sendNotification(
                        ownerId,
                        "Phương tiện của bạn đã bị phạt " + fineAmount + " VND do vi phạm giao thông.",
                        plateNumber
                );

                if (statusUpdated && violationRecorded && notificationSent) {
                    response.sendRedirect("PoliceDashboard.jsp?success=approved");
                } else {
                    response.sendRedirect("PoliceDashboard.jsp?error=failed");
                }
            } else if ("Rejected".equals(status)) {
                NotiDAO notiDAO = new NotiDAO();
                boolean notificationSent = notiDAO.sendNotification(
                        officerId,
                        "Phản ánh vi phạm đã bị từ chối.",
                        plateNumber
                );

                if (statusUpdated && notificationSent) {
                    response.sendRedirect("PoliceDashboard.jsp?success=rejected");
                } else {
                    response.sendRedirect("PoliceDashboard.jsp?error=failed");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("PoliceDashboard.jsp?error=exception");
        }
    }
}
