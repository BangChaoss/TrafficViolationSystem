package dao;

import model.Report;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import untils.DBConnection;
import java.sql.ResultSet;

public class ReportDAO {

    private Connection conn;

    public ReportDAO() {
    }
    public ReportDAO(Connection conn) {
        this.conn = conn;
    }
// Cập nhật trạng thái phản ánh
// public int getViolatorIdByPlate(String plateNumber) throws SQLException, ClassNotFoundException {
//        String query = "SELECT userId FROM Vehicles WHERE plateNumber = ?";
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement(query)) {
//            stmt.setString(1, plateNumber);
//            ResultSet rs = stmt.executeQuery();
//            if (rs.next()) {
//                return rs.getInt("userId");
//            }
//        }
//        return -1; // Không tìm thấy
//    }
//    
//    public boolean updateReportStatus(int reportId, String status, int officerId) throws SQLException, ClassNotFoundException {
//        String query = "UPDATE Reports SET status = ?, officerId = ? WHERE reportId = ?";
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement(query)) {
//            stmt.setString(1, status);
//            stmt.setInt(2, officerId);
//            stmt.setInt(3, reportId);
//            return stmt.executeUpdate() > 0;
//        }
//    }
//    
//    public boolean sendNotification(int violatorId, String message, String plateNumber) throws SQLException, ClassNotFoundException {
//        String query = "INSERT INTO Notifications (userId, message, plateNumber) VALUES (?, ?, ?)";
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement(query)) {
//            stmt.setInt(1, violatorId);
//            stmt.setString(2, message);
//            stmt.setString(3, plateNumber);
//            return stmt.executeUpdate() > 0;
//        }
//    }
//    
//    public boolean recordViolation(int violatorId, String plateNumber, double fineAmount) throws SQLException, ClassNotFoundException {
//        String query = "INSERT INTO Violations (userId, plateNumber, fineAmount, status) VALUES (?, ?, ?, 'Unpaid')";
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement(query)) {
//            stmt.setInt(1, violatorId);
//            stmt.setString(2, plateNumber);
//            stmt.setDouble(3, fineAmount);
//            return stmt.executeUpdate() > 0;
//        }
//    }


//    public boolean updateReportStatus(int reportId, String status, int processedBy) throws SQLException, ClassNotFoundException {
//        String sql = "UPDATE Reports SET Status = ?, ProcessedBy = ? WHERE ReportID = ?";
//        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
//            ps.setString(1, status);
//            ps.setInt(2, processedBy);
//            ps.setInt(3, reportId);
//            return ps.executeUpdate() > 0;
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return false;
//    }
 public int getViolatorIdByPlate(String plateNumber) throws SQLException, ClassNotFoundException {
        int violatorId = -1;
        String sql = "SELECT user_id FROM Vehicles WHERE plate_number = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, plateNumber);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                violatorId = rs.getInt("user_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return violatorId;
    }

//    public boolean updateReportStatus(int reportId, String status, int officerId) throws SQLException, ClassNotFoundException {
//        String sql = "UPDATE Reports SET status = ?, officer_id = ? WHERE report_id = ?";
//        
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement(sql)) {
//            stmt.setString(1, status);
//            stmt.setInt(2, officerId);
//            stmt.setInt(3, reportId);
//            return stmt.executeUpdate() > 0;
//        } catch (SQLException e) {
//            e.printStackTrace();
//            return false;
//        }
//    }

    public boolean sendNotification(int violatorId, String message, String plateNumber) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO Notifications (user_id, message, plate_number) VALUES (?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, violatorId);
            stmt.setString(2, message);
            stmt.setString(3, plateNumber);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean recordViolation(int violatorId, String plateNumber, double fineAmount) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO Violations (user_id, plate_number, fine_amount) VALUES (?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, violatorId);
            stmt.setString(2, plateNumber);
            stmt.setDouble(3, fineAmount);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public List<Report> getPendingReports() throws SQLException, ClassNotFoundException {
        List<Report> reports = new ArrayList<>();
        String sql = "SELECT * FROM Reports WHERE Status = 'Pending'";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                reports.add(new Report(
                         rs.getInt("reportID"),
                        rs.getInt("reporterID"),
                        rs.getString("violationType"),
                        rs.getString("description"),
                        rs.getString("plateNumber"),
                        rs.getString("imageURL"),
                        rs.getString("videoURL"),
                        rs.getString("location"),
                        rs.getTimestamp("reportDate"),
                        rs.getString("status"),
                        rs.getInt("processedBy")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reports;
    }

    // Gửi thông báo cho người vi phạm
//    public boolean sendNotification(int userId, String message, String plateNumber) throws SQLException, ClassNotFoundException {
//        String sql = "INSERT INTO Notifications (UserID, Message, PlateNumber) VALUES (?, ?, ?)";
//        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
//            ps.setInt(1, userId);
//            ps.setString(2, message);
//            ps.setString(3, plateNumber);
//            return ps.executeUpdate() > 0;
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return false;
//    }

    public boolean insertReport(Report report) {
        String sql = "INSERT INTO Reports (ReporterID, ViolationType, Description, PlateNumber, ImageURL, VideoURL, Location, ReportDate, Status, ProcessedBy) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, report.getReporterID());
            stmt.setString(2, report.getViolationType());
            stmt.setString(3, report.getDescription());
            stmt.setString(4, report.getPlateNumber());
            stmt.setString(5, report.getImageURL()); // ✅ Lưu đường dẫn ảnh
            stmt.setString(6, report.getVideoURL()); // ✅ Lưu đường dẫn video
            stmt.setString(7, report.getLocation());
            stmt.setTimestamp(8, report.getReportDate());
            stmt.setString(9, report.getStatus());
            stmt.setObject(10, report.getProcessedBy(), java.sql.Types.INTEGER);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

    }
public boolean updateReportStatus(int reportId, String status, int officerId) throws SQLException, ClassNotFoundException {
        String sql = "UPDATE Reports SET Status = ?, ProcessedBy = ? WHERE ReportID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, officerId);
            ps.setInt(3, reportId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public boolean saveReport(int reporterID, String violationType, String description,
            String plateNumber, String location, String imageURL, String videoURL) {
        String sql = "INSERT INTO Reports (ReporterID, ViolationType, Description, PlateNumber, Location, ImageURL, VideoURL, Status) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, reporterID);
            stmt.setString(2, violationType);
            stmt.setString(3, description);
            stmt.setString(4, plateNumber);
            stmt.setString(5, location);
            stmt.setString(6, imageURL != null ? imageURL : ""); // Tránh lỗi null
            stmt.setString(7, videoURL != null ? videoURL : "");

            return stmt.executeUpdate() > 0;

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Report> getReportsByUser(int userID) {
        List<Report> reports = new ArrayList<>();
        String sql = "SELECT * FROM Reports WHERE reporterID = ? ORDER BY reportDate DESC";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userID);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Report report = new Report(
                        rs.getInt("reportID"),
                        rs.getInt("reporterID"),
                        rs.getString("violationType"),
                        rs.getString("description"),
                        rs.getString("plateNumber"),
                        rs.getString("imageURL"),
                        rs.getString("videoURL"),
                        rs.getString("location"),
                        rs.getTimestamp("reportDate"),
                        rs.getString("status"),
                        rs.getInt("processedBy")
                );
                reports.add(report);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return reports;
    }

}
