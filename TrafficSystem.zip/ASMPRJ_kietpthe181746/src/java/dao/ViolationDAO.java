package dao;

import model.Violation;
import untils.DBConnection;
import java.sql.*;

public class ViolationDAO {

    private DBConnection db; // Tạo đối tượng DBConnection

    public ViolationDAO() {
        this.db = new DBConnection(); // Khởi tạo DBConnection
    }

    public boolean recordViolation(int reportId, String plateNumber, int violatorId, double fineAmount) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO Violations (ReportID, PlateNumber, ViolatorID, FineAmount) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, reportId);
            ps.setString(2, plateNumber);
            ps.setInt(3, violatorId);
            ps.setDouble(4, fineAmount);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
 public boolean addViolation(int reportId, String plateNumber, int violatorId, double fineAmount) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO Violations (ReportID, PlateNumber, ViolatorID, FineAmount) VALUES (?, ?, ?, ?)";
        try (Connection conn =  DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, reportId);
            ps.setString(2, plateNumber);
            ps.setInt(3, violatorId);
            ps.setDouble(4, fineAmount);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    // 📌 Thêm vi phạm mới
    public boolean addViolation(Violation violation) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO Violations (ReportID, PlateNumber, ViolatorID, FineAmount, FineDate, PaidStatus) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = db.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, violation.getReportID());
            stmt.setString(2, violation.getPlateNumber());
            stmt.setInt(3, violation.getViolatorID());
            stmt.setDouble(4, violation.getFineAmount());
            stmt.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
            stmt.setString(6, violation.getPaidStatus());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
