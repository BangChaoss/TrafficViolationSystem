package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import untils.DBConnection;

public class VehicleDAO {

    // Lấy OwnerID từ bảng Vehicles dựa vào PlateNumber
    public int getOwnerIdByPlate(String plateNumber) {
        int ownerId = -1; // Mặc định -1 nếu không tìm thấy
        String sql = "SELECT OwnerID FROM Vehicles WHERE PlateNumber = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, plateNumber);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                ownerId = rs.getInt("OwnerID");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ownerId;
    }
}
